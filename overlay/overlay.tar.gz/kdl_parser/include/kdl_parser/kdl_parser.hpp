/*
 * Filename: kdl_parser.hpp
 * Author: Marcus Liebhardt
 * Date: XX.02.2011
 * License: 
 */
 
 

#ifndef KDL_PARSER_H
#define KDL_PARSER_H

#include <kdl/tree.hpp>
#include <string>
#include <urdf/model.h>


namespace kdl_parser{

/** Constructs a KDL tree from a file, given the file name
 * \param file The filename from where to read the xml
 * \param tree The resulting KDL Tree
 * returns true on success, false on failure
 */
bool treeFromFile(const std::string& file, KDL::Tree& tree);

/** Constructs a KDL tree from the parameter server, given the parameter name
 * \param param the name of the parameter on the parameter server
 * \param tree The resulting KDL Tree
 * returns true on success, false on failure
 */
bool treeFromParam(const std::string& param, KDL::Tree& tree);

/** Constructs a KDL tree from a string containing xml
 * \param xml A string containting the xml description of the robot
 * \param tree The resulting KDL Tree
 * returns true on success, false on failure
 */
bool treeFromString(const std::string& xml, KDL::Tree& tree);

/** Constructs a KDL tree from a TiXmlDocument
 * \param xml_doc The TiXmlDocument containting the xml description of the robot
 * \param tree The resulting KDL Tree
 * returns true on success, false on failure
 */
bool treeFromXml(TiXmlDocument *xml_doc, KDL::Tree& tree);

/** Constructs a KDL tree from a URDF robot model
 * \param robot_model The URDF robot model
 * \param tree The resulting KDL Tree
 * returns true on success, false on failure
 */
bool treeFromUrdfModel(const urdf::Model& robot_model, KDL::Tree& tree);
}

#endif
